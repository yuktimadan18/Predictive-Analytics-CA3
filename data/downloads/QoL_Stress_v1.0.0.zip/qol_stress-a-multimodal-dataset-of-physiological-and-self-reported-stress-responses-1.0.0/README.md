# QoL_Stress Dataset

## Authors
- Amaia Calvo¹*, Ander Cejudo¹², Cristina Martin¹²³  
¹ Fundación Vicomtech, Basque Research and Technology Alliance (BRTA), Donostia-San Sebastián, Spain  
² Faculty of Engineering, University of Deusto, Bilbao, Spain  
³ BioGipuzkoa Health Research Institute, eHealth Group, Donostia-San Sebastián, Spain  

## Overview
The QoL_Stress dataset contains physiological signals, heart rate data from Fitbit devices, and stress/anxiety questionnaire responses from 66 participants. It was collected to study stress and quality-of-life patterns under controlled relaxation and stress conditions. The dataset can be used for stress detection, physiological signal analysis, and machine learning applications.

## Background
Participants underwent periods of relaxation and induced stress while physiological signals were recorded and questionnaires administered. The study focuses on healthy adults and aims to provide data for research and machine learning purposes.

## Dataset Structure
The main folder contains the following CSV files:

- **participants.csv** — participant demographics  
  **Fields:** `username`, `sex`, `age`, `education_level`, `job_category`.

- **ecg.csv** — ECG signals collected from participants  
  **Fields:** `_id`, `reading_id`, `reading_time`, `wire_id`, `result_classification`, `heart_rate`, `heart_rate_alert`, `firmware_version`, `device_app_version`, `hardware_version`, `username`, `phase`, `waveform_samples`.

- **eda.csv** — Electrodermal activity (EDA) signals  
  **Fields:** `username`, `phase`, `time_sec`, `valid_data`, `activation`, `scl_avg`.

- **fitbit_heart_rate_per_minute.csv** — minute-level heart rate  
  **Fields:** `username`, `time`, `value`.

- **fitbit_heart_rate_per_second.csv** — second-level heart rate  
  **Fields:** `username`, `time`, `value`.

- **fitbit_heart_rate_summary.csv** — daily summary of heart rate zones  
  **Fields:** `username`, `zone_name`, `min`, `max`, `minutes`, `caloriesOut`.

- **pss_14.csv** — Perceived Stress Scale questionnaire responses  
  **Fields:** `username`, `time`, `score`, plus one column per question.

- **stai.csv** — State-Trait Anxiety Inventory questionnaire responses  
  **Fields:** `username`, `time`, `phase`, `score`, plus one column per question.

**Statistics:**  
- 66 participants  
- 132 ECG records  
- 124 EDA records  
- 66 Fitbit records  

## Data Description
For a detailed description of each data type and which files contain it, see `data_description.csv`.

## Usage Notes
The dataset can be used to:
- Develop machine learning models for stress detection.
- Analyze ECG, EDA, and heart rate responses to stress.
- Benchmark physiological signal preprocessing methods.
- Study relationships between perceived stress and physiological responses.

## Ethics
- Protocol approved by the institutional review board.  
- All participants gave written informed consent.  
- Data is anonymized to protect privacy.

## Acknowledgements
Thanks to all participants and the data collection team. This work was supported by Fundación Vicomtech.
